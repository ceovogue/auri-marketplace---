export default function Demo() {
  return (
    <iframe
      src="/index1.html"
      style={{ width: "100%", height: "100vh", border: "0" }}
    />
  );
}

