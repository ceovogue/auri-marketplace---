export default function Page() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Σελίδα υπό κατασκευή</h1>
      <p>Έρχεται σύντομα.</p>
    </main>
  );
}
