
export default function ClassifiedsPage() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Αγγελίες Ακινήτων</h1>
      <p>Σελίδα υπό κατασκευή — έρχεται σύντομα.</p>
    </main>
  );
}
